import customerRoutes from "./Customer";

const moduleRoutesMap = {
  ...customerRoutes
};
export default moduleRoutesMap;
