import { baseRoutes } from "../../../helpers/baseRoutes";

const accessRoute = {
  TELEPHONY: {
    path: `${baseRoutes.adminBaseRoutes}telephony`
  },
};

export default accessRoute;
