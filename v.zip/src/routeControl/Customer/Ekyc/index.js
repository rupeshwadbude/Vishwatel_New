import { baseRoutes } from "../../../helpers/baseRoutes";

const accessRoute = {
  EKYC: {
    path: `${baseRoutes.adminBaseRoutes}ekyc`
  },
};

export default accessRoute;
