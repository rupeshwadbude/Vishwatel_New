import { baseRoutes } from "../../../helpers/baseRoutes";

const accessRoute = {
  PROFILEUPDATE: {
    path: `${baseRoutes.adminBaseRoutes}profile-update`
  },
};

export default accessRoute;
