import customerRoute from "./Customer";

const customerRouteMap = {
  ...customerRoute
};
export default customerRouteMap;
