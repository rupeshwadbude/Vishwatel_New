export const baseRoutes = {
  adminBaseRoutes: "/",
};
