import { Calendar as AntCalender } from "antd";

function Calendar({ ...rest }) {
  return <AntCalender {...rest} />;
}
export default Calendar;
